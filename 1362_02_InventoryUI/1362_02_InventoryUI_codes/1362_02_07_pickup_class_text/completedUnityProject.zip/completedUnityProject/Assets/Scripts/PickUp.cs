﻿using UnityEngine;
using System.Collections;

public class PickUp : MonoBehaviour {
	public string description;
}
