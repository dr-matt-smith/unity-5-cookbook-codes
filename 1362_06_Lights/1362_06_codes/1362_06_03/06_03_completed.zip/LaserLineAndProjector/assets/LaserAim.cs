﻿using UnityEngine;
using System.Collections;
/* ----------------------------------------
 * class to demonstrate how to use a Line Renderer
 * and a Projector to create a Laser Aim effect
 */ 
public class LaserAim : MonoBehaviour {
	// float variable for the laser line width
	public float lineWidth = 0.2f;
	// the color of the line whenever the weapon is NOT being fired.
	public Color regularColor = new Color (0.15f, 0, 0, 1);
	// the color of the line whenever the weapon is being fired.
	public Color firingColor = new Color (0.31f, 0, 0, 1);
	// Material to be applied on the line renderer for the laser
	public Material lineMat;
	// Vector 3 variable for the position where the line ends 
	private Vector3 lineEnd;
	// Variable for the Projector component
	private Projector proj;
	// Variable for the Line Renderer component
	private LineRenderer line;

	/* ----------------------------------------
 	* At Start, set up effects components (Line Renderer and Projector)
 	*/ 
	void Start () {
		// Add Line Renderer component
		line = gameObject.AddComponent<LineRenderer>();
		// Set the Material for the Line Renderer
		line.material = lineMat;
		// Set initial color for the Line Renderer's material
		line.material.SetColor("_TintColor", regularColor);
		// Set number of vertices 
		line.SetVertexCount(2);
		// Set Line Renderer's width at each vertex
		line.SetWidth(lineWidth, lineWidth);
		// Assign object's Projector component to proj variable
		proj = GetComponent<Projector> ();
	}
	
	/* ----------------------------------------
	 * During Update, adjust the range of the line and projector to the object being aimed at.
	 * Also, animate the Line's color if the Fire button is pressed. We will do that by interpolating between 'regularColor' and 'firingColor',
	 * making it look as if pulsing
	 */
	void Update () {
		// Create RaycastHit variable to detect if the projector is aiming at any object's collider
		RaycastHit hit; 
		
		// Create 3D Vector for keeping the projector's forward direction 
		Vector3 fwd = transform.TransformDirection(Vector3.forward);
		
		if (Physics.Raycast (transform.position, fwd, out hit)) {
			// IF Ray cast from projector to its forward direction hits something, THEN set hit poit as the Line's end...
			lineEnd =  hit.point;
			//... also, create a float variable for increasing the projector's far clip plane a bit
			float margin = 0.5f;
			// Place the projector's far clip plane a bit over the hit point
			proj.farClipPlane = hit.distance + margin;

		} else {
			// IF Ray cast from projector to its forward direction DOES NOT hit something, THEN place the Line's end at an arbitrary distance in the projector's forward direction
			lineEnd = transform.position + fwd * 10f;
		}
		// Set the position of the Line's initial vertex at the projector's origin
		line.SetPosition(0, transform.position);
		// Set the position of the Line's final vertex at the point stored at the lineEnd vector
		line.SetPosition(1, lineEnd);

		if(Input.GetButton("Fire1")){
			// IF the 'Fire' button is pressed, THEN use a Sine function to get a value between -1 and 1
			float lerpSpeed = Mathf.Sin (Time.time * 10f);
			// Get the absolute value of 'lerpSpeed', so it can be used as an interpolation value
			lerpSpeed = Mathf.Abs(lerpSpeed);
			// Set up a color between 'regularColor' and 'firingColor' 
			Color lerpColor = Color.Lerp(regularColor, firingColor, lerpSpeed);
			// Set 'lerpColor' as the Tint Color for the Line Renderer's material. 
			line.material.SetColor("_TintColor", lerpColor);

		}
		if(Input.GetButtonUp("Fire1")){
			// IF the 'Fire' button is released, THEN restore Tint Color for the Line Renderer's material
			line.material.SetColor("_TintColor", regularColor);
		}
	}
}
