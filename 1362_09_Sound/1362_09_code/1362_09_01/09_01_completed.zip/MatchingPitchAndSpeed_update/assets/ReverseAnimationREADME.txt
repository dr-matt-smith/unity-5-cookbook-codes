To allow for reverse animation: 
1 - Open the Animator
2 - Use the plus (+) to create a Float Parameter named 'Speed'. *
3 - Select the 'spin' Animator state. *
4 - From the Inspector view, check �Parameter� box in Multiplier and select �Speed�. *
5 - Apply script �ChangePitchReverse� to animatedRocket.
6 - Test the scene and press '1' and '2' on keyboard to accelerate and decelerate speed. 

* For visual explanation, see ReverseAnimatorSetup.PNG file on Assets folder. Also, please check �ChangePitchReverse� 
commented code for further explanation