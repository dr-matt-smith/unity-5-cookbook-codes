﻿using UnityEngine;
using System.Collections;

public class IncrementCorrectScore : MonoBehaviour {
	void Start () {
		Player.scoreCorrect++;	
	}
}
