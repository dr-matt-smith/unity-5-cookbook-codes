﻿using UnityEngine;
using System.Collections;

public class IncrementIncorrectScore : MonoBehaviour {
	void Start () {
		Player.scoreIncorrect++;	
	}
}
