﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {
	public static int scoreCorrect = 0;
	public static int scoreIncorrect = 0;
}
