// file: SimpleMath.cs
using UnityEngine;
using System.Collections;

public class SimpleMath : MonoBehaviour {
	public float Halve(float n){
		return n / 2;
	}
}
